package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/bbs/*")
public class BBSController {
	@RequestMapping(value = "/main")
	public void main(Model model) {
		
	}
	
	@RequestMapping(value = "/bbs")
	public void bbs(Model model) {

	}
	
	@RequestMapping(value = "/view")
	public void view(Model model) {

	}
}
