package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller 
@RequestMapping("/action/*")
public class ActionController {
	@RequestMapping(value = "/deleteAction")
	public void deleteAction(Model model) {
		
	}
	
	@RequestMapping(value = "/loginAction")
	public void loginAction(Model model) {

	}
	
	@RequestMapping(value = "/joinAction")
	public void joinAction(Model model) {

	}
	
	@RequestMapping(value = "/logoutAction")
	public void logoutAction(Model model) {

	}
	
	@RequestMapping(value = "/updateAction")
	public void updateAction(Model model) {

	}
	
	@RequestMapping(value = "/writeAction")
	public void writeAction(Model model) {

	}
	
	@RequestMapping(value = "/join")
	public void join(Model model) {

	}
	
	@RequestMapping(value = "/login")
	public void login(Model model) {

	}
	
	@RequestMapping(value = "/update")
	public void update(Model model) {

	}
	
	@RequestMapping(value = "/write")
	public void write(Model model) {

	}
}
